# Crypto Market Data Analysis  

This project fetches real-time **Bitcoin price data** from Binance API and visualizes it.  

## Features  
- Fetches live **BTC price data**.  
- Plots **price trends** using Matplotlib.  
- Creates **candlestick charts** with mplfinance.  
- Saves data to **CSV file**.  

## Installation  
```bash
pip install requests pandas matplotlib mplfinance
